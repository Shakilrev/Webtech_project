<footer class="footer">
    <div class="container">
        <div class="copyright-text">
            <p>Copyright &copy; 2023 MedioSoft. All rights are reserved.</p>
        </div>
    </div>
</footer>
<script src="../assets/js/script.js"></script>
</body>
</html>